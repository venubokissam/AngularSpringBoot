package com.springboot.rest.backend.models.auth;

public class JwtConfig {

	public static String SIGN_SECRETE = "any.key.secrete.12345678";
	
	public static String RSA_PRIVATE = "-----BEGIN RSA PRIVATE KEY-----\r\n" + 
			"MIIEpAIBAAKCAQEAszLt2R/ro/v8r+ew/ljAAtnDnqLop+cCoUkN0vS6Cu+yyqAy\r\n" + 
			"NipOFoEB31RPClTu56FDkDSnAf+UmlDCWRBLMpxqHXJ9okasU4+haA1qRCOTbGQh\r\n" + 
			"R8V6YDlXlyekhqt2OhCh2MqQ2Cvssn4LIBnLQFTQZrLPWVuyPBttjpO2p+WA/YIf\r\n" + 
			"fbotFMHfE+F3bIFn4uy+8uhPT2+xrp3e5mf7CrdcO8YngNK+n2wxAzlFKEpEWlYZ\r\n" + 
			"y85QFjVONAatdKhqMotO+lHCd2wKZVB3p1mUX5hoZ0eHbAUvJUXAbEZ99q7aODVU\r\n" + 
			"KfwV/3GMRmFJ1n/MLDkDsP44bu0krz0a9THWPQIDAQABAoIBAQCcRkDYRhcYlguC\r\n" + 
			"V/qphTpGAiSvtoBQ1IwdnXj5zMRl/y2buWKwi+o3g9/fJEYdy33g8GjcXJ58hqfQ\r\n" + 
			"f7dNNoFtrKx567uWhi2IXcyz0mcm7yOEtjmzvor/WWKChmbbrrHW52RNjDIO4xdz\r\n" + 
			"fao0H2p6OrzXov5ifi4Mbxr26Oi0t2HV6ga5fQUZzuMfeLUyAFo/3bX4H2zmkqlR\r\n" + 
			"jTSyWC8NIb63WihmC8wGvZl1WEvswnyUl5KI3/38GzsBXUZ0Hqib3TsGQ6nXGfM9\r\n" + 
			"yqB1bQvt0RGE5wHs5Nbxz7titkKXZPSVRyLc97qlrmtukPtZq//KG1Ag8wfJNWt+\r\n" + 
			"jo80tlWhAoGBAOGpLq8/r4W64qAfJFlhJGl/uUyrSuzivtxRAir9KyaOWrZ8iNun\r\n" + 
			"xEHy25PgL1OpiiavAGzMkrOH/mKaPe/9LFDf/PUkH4g4JFdd+T3M4WNSTOIhOgft\r\n" + 
			"Bmkkovaj0o4GVbge2vvwErlA0T5FgycKXto2O6zJHJvA9NNZg46UfXTJAoGBAMtK\r\n" + 
			"nZotyILZzXx2fRavtRJYimbmGckLDO9zm5OE/TN+J4037X3MjwkPFQuLh+SU0VGp\r\n" + 
			"3WQAeu4ihSGXI+EZ/WRzKTFsUEzpwCcPJOM3ZI/onopj4cJl3jAdzSto53Dv4UB5\r\n" + 
			"2F70Gbr/qx3zVrLWM2t46EgcG61ZoCnvldLCHtPVAoGAeDYICJOEjVjhISt10adO\r\n" + 
			"HmVL8OvPHiIsSnFdFkmHkyKCcHQm89yLUBZvonbqv0axsanIMC1KeRkZCq3gENht\r\n" + 
			"oyevOWfk5EwEEAafn6xk5OQS0OOiZlZ988TwizL6F26Ie2z0ewGI9+bvkJy3ITUF\r\n" + 
			"EnmRkJoSA2bnBS/KRUoVCwECgYBT2fsX1TqXfm8bn2QJL4BoiMzNlKueGUjEm9LY\r\n" + 
			"DkrCKo712NPEx9NX0TjFAlCTIC8WmBIRZYFPKD3xlP3fo3C5NicPk7Wrg98WPVDh\r\n" + 
			"x79a/IAoZPqBzLLQ9fnipeqQ0uD+T0PIJrdWQo66U9y291NOSRjGZZGk9wrxQTlz\r\n" + 
			"LU654QKBgQDg14qEI5CYIkeJOeA/U5yZsnY8l3M6ht3oFRcm486BBTfv5mUbdH6d\r\n" + 
			"vi6ynipEQjv27+lxREnSB6u1PN/vv8FbCYStJ9Rn6KKnU7yGEcX8DnpPlNyr1U9J\r\n" + 
			"7WATPngExcjpKxTaJumB5K2PyQvRHcGZPm40L5IEdShFwj4x42ejig==\r\n" + 
			"-----END RSA PRIVATE KEY-----";
	
	public static String RSA_PUBLIC = "-----BEGIN PUBLIC KEY-----\r\n" + 
			"MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAszLt2R/ro/v8r+ew/ljA\r\n" + 
			"AtnDnqLop+cCoUkN0vS6Cu+yyqAyNipOFoEB31RPClTu56FDkDSnAf+UmlDCWRBL\r\n" + 
			"MpxqHXJ9okasU4+haA1qRCOTbGQhR8V6YDlXlyekhqt2OhCh2MqQ2Cvssn4LIBnL\r\n" + 
			"QFTQZrLPWVuyPBttjpO2p+WA/YIffbotFMHfE+F3bIFn4uy+8uhPT2+xrp3e5mf7\r\n" + 
			"CrdcO8YngNK+n2wxAzlFKEpEWlYZy85QFjVONAatdKhqMotO+lHCd2wKZVB3p1mU\r\n" + 
			"X5hoZ0eHbAUvJUXAbEZ99q7aODVUKfwV/3GMRmFJ1n/MLDkDsP44bu0krz0a9THW\r\n" + 
			"PQIDAQAB\r\n" + 
			"-----END PUBLIC KEY-----";
}
