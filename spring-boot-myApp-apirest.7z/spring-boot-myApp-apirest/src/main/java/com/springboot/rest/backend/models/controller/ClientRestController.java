package com.springboot.rest.backend.models.controller;

import java.io.IOException;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.core.io.Resource;
import javax.validation.Valid;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.annotation.Secured;
import org.springframework.validation.BindingResult;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.springboot.rest.backend.models.entity.Client;
import com.springboot.rest.backend.models.entity.Region;
import com.springboot.rest.backend.models.service.IClientService;
import com.springboot.rest.backend.models.service.IUploadFileService;


@RestController
@RequestMapping("/api")
public class ClientRestController {
	
	@Autowired
	private IClientService clientService;
	@Autowired
	private IUploadFileService uploadFileService;
	
	private final Logger logger = LoggerFactory.getLogger(ClientRestController.class);
	@GetMapping("/clients")
	public List<Client> index(){
		return clientService.findAll();
	}
	
	@GetMapping("/clients/page/{page}")
	public Page<Client> index(@PathVariable Integer page){
		Pageable pageable = PageRequest.of(page,4);
		return clientService.findAll(pageable);
	}
	
	//@Secured({"ROLE_USER","ROLE_ADMIN"})
	@GetMapping("/clients/{id}")
	public ResponseEntity<?> show(@PathVariable Long id) {
		Client client = null;
		Map<String,Object> response = new HashMap<>();
		try {
			 client = clientService.findById(id);
		}catch(DataAccessException e) {
			response.put("message","Error during finding the record, Please contact admin");
			response.put("error",e.getMessage().concat(":").concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity<Map<String,Object>>(response,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		if(client==null) {
			response.put("message","Client Id :" .concat(id.toString().concat("Not Exist!")));
			return new ResponseEntity<Map<String,Object>>(response,HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<Client>(client,HttpStatus.OK);
	}
	
	@Secured("ROLE_ADMIN")
	@PostMapping("/clients")
	@ResponseStatus(HttpStatus.CREATED)
	public ResponseEntity<?> create(@Valid @RequestBody Client client, BindingResult result) {
		
		Client clientNew= null;
		Map<String,Object> response = new HashMap<>();
		List<String> errors = new ArrayList<>();
		if(result.hasErrors()) {
		
			for(FieldError  err : result.getFieldErrors()) {
				errors.add("Field " + " " +err.getDefaultMessage());
			}
			response.put("errors", errors);
			return new ResponseEntity<Map<String,Object>>(response,HttpStatus.BAD_REQUEST);
		}
		
		try {
			clientNew = clientService.save(client);
		}catch(DataAccessException e) {
			response.put("message","Error during save, Please contact admin");
			response.put("error",e.getMessage().concat(":").concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity<Map<String,Object>>(response,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		response.put("message","Cleint has been created Successfully");
		response.put("client",clientNew);
		return new ResponseEntity<Map<String,Object>>(response,HttpStatus.CREATED);
	}

	@Secured("ROLE_ADMIN")
	@PutMapping("/clients/{id}")
	@ResponseStatus(HttpStatus.CREATED)
	public ResponseEntity<?> update(@Valid @RequestBody Client client, BindingResult result, @PathVariable Long id) {
		
		Client clientActual = clientService.findById(id);
		Client clientUpdated = null;
		Map<String,Object> response = new HashMap<>();
		
		List<String> errors = new ArrayList<>();
		if(result.hasErrors()) {
		
			for(FieldError  err : result.getFieldErrors()) {
				errors.add("Fields " +err.getField() + " " +err.getDefaultMessage());
			}
			response.put("errors", errors);
			return new ResponseEntity<Map<String,Object>>(response,HttpStatus.BAD_REQUEST);
		}
		
		if(clientActual==null) {
			response.put("message","Cannot Update, Client Id :" .concat(id.toString().concat("Not Exist!")));
			return new ResponseEntity<Map<String,Object>>(response,HttpStatus.NOT_FOUND);
		}
		try {
			clientActual.setFirstName(client.getFirstName());
			clientActual.setLastName(client.getLastName());
			clientActual.setEmail(client.getEmail());
			clientActual.setCreatedDate(client.getCreatedDate());
			clientActual.setRegion(client.getRegion());
			
			clientUpdated = clientService.save(clientActual);
		}catch(DataAccessException e) {
			response.put("message","Error during Updated, Please contact admin");
			response.put("error",e.getMessage().concat(":").concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity<Map<String,Object>>(response,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		
		response.put("message","Cleint has been Updated Successfully");
		response.put("client",clientUpdated);
		return new ResponseEntity<Map<String,Object>>(response,HttpStatus.CREATED);
		
	}
	
	@Secured("ROLE_ADMIN")
	@DeleteMapping("/clients/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public ResponseEntity<?> delete(@PathVariable Long id) {
		Map<String,Object> response = new HashMap<>();
		try {
			
			Client client = clientService.findById(id);
			
			String prevPhoto = client.getPhoto();
			uploadFileService.remove(prevPhoto);
			
		   clientService.delete(id);
		}catch(DataAccessException e) {
			response.put("message","Error during Delete, Please contact admin");
			response.put("error",e.getMessage().concat(":").concat(e.getMostSpecificCause().getMessage()));
			return new ResponseEntity<Map<String,Object>>(response,HttpStatus.INTERNAL_SERVER_ERROR);
		}
		response.put("message","Cleint has been Updated Successfully");
		return new ResponseEntity<Map<String,Object>>(response,HttpStatus.OK);
		
	}
	
	@Secured({"ROLE_USER","ROLE_ADMIN"})
	@PostMapping("clients/upload")
	public ResponseEntity<?> upload(@RequestParam("archive") MultipartFile archive, @RequestParam("id") Long id){
		Map<String,Object> response = new HashMap<>();
		
		
		Client client = clientService.findById(id);
		
		if(!archive.isEmpty()) {
			
			String archiveName = null;
			try{
				archiveName = uploadFileService.copy(archive);
			}catch(IOException e) {
				response.put("message","Error during Upload Image, Please contact admin");
				response.put("error",e.getMessage().concat(":").concat(e.getCause().getMessage()));
				return new ResponseEntity<Map<String,Object>>(response,HttpStatus.INTERNAL_SERVER_ERROR);
			}
			
			//delete previous images
			String prevPhoto = client.getPhoto();
			uploadFileService.remove(prevPhoto);
			 
			client.setPhoto(archiveName);
			clientService.save(client);
			
			response.put("client",client);
			response.put("message","Have uploaded correct Image "+archiveName);
		}
		
		return new ResponseEntity<Map<String,Object>>(response,HttpStatus.CREATED);
	}
	
	@GetMapping("/uploads/img/{photoName:.+}")
	public ResponseEntity<Resource> getPhoto(@PathVariable String photoName){
		
		Resource resource  = null;
		try {
			resource = uploadFileService.load(photoName);
		} catch (MalformedURLException e) {
			e.printStackTrace();
		}
		
		HttpHeaders headers = new HttpHeaders();
		headers.add(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"");
		return new ResponseEntity<Resource>(resource,headers,HttpStatus.OK);
	}
	
	@Secured("ROLE_ADMIN")
	@GetMapping("/clients/regions")
	public List<Region> lsitOfRegions(){
		return clientService.findAllRegions();
	}
	
}
