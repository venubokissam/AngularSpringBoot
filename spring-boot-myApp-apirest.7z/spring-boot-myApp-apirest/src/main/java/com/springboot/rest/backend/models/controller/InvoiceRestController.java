package com.springboot.rest.backend.models.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.annotation.Secured;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.springboot.rest.backend.models.entity.Invoice;
import com.springboot.rest.backend.models.entity.Product;
import com.springboot.rest.backend.models.service.IClientService;


@RestController
@RequestMapping("/api")
public class InvoiceRestController {

	@Autowired
	private IClientService clientService;
	
	//@Secured({"ROLE_USER","ROLE_ADMIN"})
	@GetMapping("/invoices/{id}")
	@ResponseStatus(HttpStatus.OK)
	public Invoice show(@PathVariable Long id) {
		return clientService.findInvoiceById(id);
	}
	
	@DeleteMapping("/invoices/{id}")
	@ResponseStatus(HttpStatus.NO_CONTENT)
	public void delete(@PathVariable Long id) {
		clientService.deleteInvoice(id);
	}
	
	@GetMapping("/invoices/filter-products/{term}")
	@ResponseStatus(HttpStatus.OK)
	public List<Product> filterProducts(@PathVariable String term){
		return clientService.findByProductName(term);
	}
}
