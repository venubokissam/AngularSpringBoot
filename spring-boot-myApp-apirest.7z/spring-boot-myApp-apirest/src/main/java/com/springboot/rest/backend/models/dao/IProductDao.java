package com.springboot.rest.backend.models.dao;

import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.springboot.rest.backend.models.entity.Product;

public interface IProductDao extends CrudRepository<Product,Long>{

	@Query("select p from Product p where p.productName like %?1%")
	public List<Product> findByProductName(String productName);
	
	public List<Product> findByProductNameContainingIgnoreCase(String productName);
	
	public List<Product> findByProductNameStartingWithIgnoreCase(String productName);
	
}
