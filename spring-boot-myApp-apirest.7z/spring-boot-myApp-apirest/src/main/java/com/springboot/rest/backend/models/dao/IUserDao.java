package com.springboot.rest.backend.models.dao;

import org.springframework.data.repository.CrudRepository;

import com.springboot.rest.backend.models.entity.User;

public interface IUserDao extends CrudRepository<User,Long>{

	public User findByUsername(String username);
	
}
