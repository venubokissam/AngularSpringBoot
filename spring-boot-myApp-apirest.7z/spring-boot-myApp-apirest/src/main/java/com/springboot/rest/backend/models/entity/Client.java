package com.springboot.rest.backend.models.entity;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.PrePersist;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;



@Entity
@Table(name="Client")
public class Client implements Serializable{

	
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;
	
	@NotEmpty(message="FirstName cannot be empty.")
	@Size(min=5,max=12,message="FirstName between 5 to 12 characters.")
	@Column(nullable=false)
	private String firstName;
	
	@NotEmpty(message="LastName cannot be empty.")
	@Column(nullable=false)
	private String lastName;
	
	@NotNull(message="CreateDate is mandatory")
	@Column(name="createdDate")
	@Temporal(TemporalType.DATE)
	private Date createdDate;
	
	/*
	 * @PrePersist public void prePersist() { createdDate = new Date(); }
	 */
	
	@NotEmpty(message="Email cannot be empty.")
	@Email(message="Email should be in correct format.")
	@Column(nullable=false,unique=true)
	private String email;
	
	private String photo;
	
	@JsonIgnoreProperties({"client","hibernateLazyIntializer","handler"})
	@OneToMany(fetch=FetchType.LAZY,mappedBy="client",cascade=CascadeType.ALL)
	private List<Invoice> invoices;
	
	public Client() {
		this.invoices= new ArrayList<>();
	}
	
	public List<Invoice> getInvoices() {
		return invoices;
	}
	public void setInvoices(List<Invoice> invoices) {
		this.invoices = invoices;
	}
	public String getPhoto() {
		return photo;
	}
	public void setPhoto(String photo) {
		this.photo = photo;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Date getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	
	@NotNull(message="Region is Mandatory")
	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="region_id")
	@JsonIgnoreProperties({"hibernateLazyIntializer","handler"})
	public Region region;

	public Region getRegion() {
		return region;
	}
	public void setRegion(Region region) {
		this.region = region;
	}
	
}
