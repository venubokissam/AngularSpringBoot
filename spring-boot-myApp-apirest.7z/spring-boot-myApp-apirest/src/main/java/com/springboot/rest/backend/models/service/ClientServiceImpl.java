package com.springboot.rest.backend.models.service;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.springboot.rest.backend.models.dao.IClientDao;
import com.springboot.rest.backend.models.dao.IProductDao;
import com.springboot.rest.backend.models.entity.Client;
import com.springboot.rest.backend.models.entity.Invoice;
import com.springboot.rest.backend.models.entity.Product;
import com.springboot.rest.backend.models.entity.Region;

@Service
public class ClientServiceImpl implements IClientService{

	@Autowired
	private IClientDao clientDao;
	
	@Autowired
	private IInvoiceDao invoiceDao;
	
	@Autowired
	private IProductDao productDao;
	
	@Override
	@Transactional(readOnly=true)
	public List<Client> findAll(){
		return (List<Client>) clientDao.findAll();
	}
	
	@Override
	@Transactional(readOnly=true)
	public Page<Client> findAll(Pageable pageable) {
		// TODO Auto-generated method stub
		return clientDao.findAll(pageable);
	}
	
	@Override
	@Transactional(readOnly=true)
	public Client findById(Long id) {
		// TODO Auto-generated method stub
		return clientDao.findById(id).orElse(null);
	}

	@Override
	public Client save(Client client) {
		// TODO Auto-generated method stub
		return clientDao.save(client);
	}

	@Override
	public void delete(Long id) {
		// TODO Auto-generated method stub
		clientDao.deleteById(id);
	}

	@Override
	@Transactional(readOnly=true)
	public List<Region> findAllRegions() {
		// TODO Auto-generated method stub
		return clientDao.findAllRegions();
	}

	@Override
	@Transactional(readOnly=true)
	public Invoice findInvoiceById(Long id) {
		// TODO Auto-generated method stub
		return invoiceDao.findById(id).orElse(null);	
	}

	@Override
	public Invoice saveInvoice(Invoice invoice) {
		// TODO Auto-generated method stub
		return invoiceDao.save(invoice);
	}

	@Override
	public void deleteInvoice(Long id) {
		// TODO Auto-generated method stub
		invoiceDao.deleteById(id);
		
	}

	@Override
	@Transactional(readOnly=true)
	public List<Product> findByProductName(String productName) {
		// TODO Auto-generated method stub
		return productDao.findByProductNameContainingIgnoreCase(productName);
	}

}
