package com.springboot.rest.backend.models.service;

import org.springframework.data.repository.CrudRepository;

import com.springboot.rest.backend.models.entity.Invoice;

public interface IInvoiceDao extends CrudRepository<Invoice, Long>{

}
