package com.springboot.rest.backend.models.service;

import com.springboot.rest.backend.models.entity.User;

public interface IUserService {

	public User findByUsername(String username);
}
