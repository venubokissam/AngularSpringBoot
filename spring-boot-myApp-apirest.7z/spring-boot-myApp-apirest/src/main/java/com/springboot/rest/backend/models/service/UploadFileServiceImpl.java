package com.springboot.rest.backend.models.service;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import java.util.UUID;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
public class UploadFileServiceImpl implements IUploadFileService{

	private final Logger logger = LoggerFactory.getLogger(UploadFileServiceImpl.class);
	private final static String DIRECTORY_UPLOAD = "uploads";
	
	@Override
	public Resource load(String photoName) throws MalformedURLException {
		Path rootArchive = getPath(photoName);
		Resource resource = null;
		logger.info(rootArchive.toString());
		try {
		resource = new UrlResource(rootArchive.toUri());
		logger.info(resource.toString());
		}catch(MalformedURLException e) {
			e.printStackTrace();
		}
		
		if(!resource.exists() && !resource.isReadable()) {
			rootArchive = Paths.get("src/main/resources/static/images").resolve("noUser.png").toAbsolutePath();
			
			try {
				resource = new UrlResource(rootArchive.toUri());
				logger.info(resource.toString());
				}catch(MalformedURLException e) {
					e.printStackTrace();
				}
			
			logger.error("Error on fetching the image" + photoName);
			
		}
		return resource;
	}

	@Override
	public String copy(MultipartFile archive) throws IOException {
		String firstArchive = UUID.randomUUID().toString()+"_"+archive.getOriginalFilename().replace(" ","");
		Path rootArchive = getPath(firstArchive);
		logger.info(rootArchive.toString());
		Files.copy(archive.getInputStream(), rootArchive);
	
		return firstArchive;
	}

	@Override
	public boolean remove(String photoName) {
		//delete previous images
		
		if(photoName!=null && photoName.length()>0) {
			Path rootPathArchive = Paths.get(DIRECTORY_UPLOAD).resolve(photoName).toAbsolutePath();
			File prevPhotoarchive = rootPathArchive.toFile();
			if(prevPhotoarchive.exists() && prevPhotoarchive.canRead()) {
				prevPhotoarchive.delete();
				return true;
			}
		}
		return false;
	}

	@Override
	public Path getPath(String photoName) {
		// TODO Auto-generated method stub
		return Paths.get(DIRECTORY_UPLOAD).resolve(photoName).toAbsolutePath();
	}

}
