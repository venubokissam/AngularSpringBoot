/*populate table client */

insert into regions (id,name) values ('1','Hyderabad');
insert into regions (id,name) values ('2','Mumbai');
insert into regions (id,name) values ('3','Culcatta');
insert into regions (id,name) values ('4','Karnataka');
insert into regions (id,name) values ('5','Guntur');
insert into regions (id,name) values ('6','Delhi');
insert into regions (id,name) values ('7','MadhyaPradesh');
insert into regions (id,name) values ('8','Ongole');

insert into client (first_Name,last_Name,created_Date,email,region_id) values('venu847','bokissam','2017-12-10','venubokissam@gmail.com','1');
insert into client (first_Name,last_Name,created_Date,email,region_id) values('venu19904','bokissam1','2017-12-10','venubokissam1@gmail.com','2');
insert into client (first_Name,last_Name,created_Date,email,region_id) values('venu2ii94','bokissam2','2017-12-10','venubokissam2@gmail.com','3');
insert into client (first_Name,last_Name,created_Date,email,region_id) values('venu3','bokissam3','2017-12-10','venubokissam3@gmail.com','4');
insert into client (first_Name,last_Name,created_Date,email,region_id) values('venu4','bokissam4','2017-12-10','venubokissam4@gmail.com','5');
insert into client (first_Name,last_Name,created_Date,email,region_id) values('venu5','bokissam5','2017-12-10','venubokissam5@gmail.com','6');
insert into client (first_Name,last_Name,created_Date,email,region_id) values('venu6','bokissam6','2017-12-10','venubokissam6@gmail.com','7');
insert into client (first_Name,last_Name,created_Date,email,region_id) values('venu7','bokissam7','2017-12-10','venubokissam7@gmail.com','1');
insert into client (first_Name,last_Name,created_Date,email,region_id) values('venu8','bokissam8','2017-12-10','venubokissam8@gmail.com','2');
insert into client (first_Name,last_Name,created_Date,email,region_id) values('venu9','bokissam9','2017-12-10','venubokissam9@gmail.com','3');
insert into client (first_Name,last_Name,created_Date,email,region_id) values('venu10','bokissam10','2017-12-10','venubokissam10@gmail.com','4');

insert into users(username,password,enabled,firstname,lastname,email) values('venu19904','$2a$10$bS/sqvBF94v/xyDTtcfm9eQnHjBn5GD1xpOXwemfi9O0tSLhFe0Gy',1,'venu123','bokka','venuboka@gmail.com');
insert into users(username,password,enabled,firstname,lastname,email) values('admin','$2a$10$wMCy3qqmN7ZDStQcq2V.KeJ7XwLy3O4iWO5qX94seCrQh9uBYc74S',1,'admin123','bokkaAdmin','admin@gmail.com');

insert into roles(name) values('ROLE_USER');
insert into roles(name) values('ROLE_ADMIN');

insert into users_roles (user_id,role_id) values (1,1);
insert into users_roles (user_id,role_id) values (2,2);
insert into users_roles (user_id,role_id) values (2,1);

insert into products (product_name, product_price,create_at) values ('Panasonic LED','37474',NOW());
insert into products (product_name, product_price,create_at) values ('Apple Iphone','8775',NOW());
insert into products (product_name, product_price,create_at) values ('Sony RRR','4543',NOW());
insert into products (product_name, product_price,create_at) values ('Dell Laptop','2334',NOW());
insert into products (product_name, product_price,create_at) values ('Asus Mobile','1475',NOW());
insert into products (product_name, product_price,create_at) values ('Iphone Laptop','5444',NOW());
insert into products (product_name, product_price,create_at) values ('Samsung s9','43443',NOW());


insert into invoice (description,remarks,client_id,create_at) values ('Invoice for Office Equipment',null,'1',NOW());
insert into invoice_items (quantity, invoice_id, product_id) values ('2','1','1');
insert into invoice_items (quantity, invoice_id, product_id) values ('1','1','2');
insert into invoice_items (quantity, invoice_id, product_id) values ('2','1','1');
insert into invoice_items (quantity, invoice_id, product_id) values ('3','1','3');
insert into invoice_items (quantity, invoice_id, product_id) values ('6','1','1');

insert into invoice (description,remarks,client_id,create_at) values ('Invoice for Building Equipment',null,'1',NOW());
insert into invoice_items (quantity, invoice_id, product_id) values ('4','2','4');
insert into invoice_items (quantity, invoice_id, product_id) values ('5','2','5');
