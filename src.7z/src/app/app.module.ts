import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { DirectiveComponent } from './directive/directive.component';
import { ClientsComponent } from './clients/clients.component';
import { PaginatorComponent } from './paginator/paginator.component';
import { ClientService } from './clients/client.service';
import { RouterModule,Routes }from '@angular/router';
import { HttpClientModule,HTTP_INTERCEPTORS } from '@angular/common/http';
import { FormComponent } from './clients/form.component';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';


import {MatDatepickerModule, MatNativeDateModule} from '@angular/material';
import {MatMomentDateModule} from '@angular/material-moment-adapter';
import { DetailComponent } from './clients/detail/detail.component';
import { LoginComponent } from './users/login.component';
import { AuthService } from './users/auth.service';
import { AuthGuard } from './users/guards/auth.guard';
import { RoleGuard } from './users/guards/role.guard';
import { TokenInterceptor } from './users/interceptors/token.interceptor';
import { AuthInterceptor } from  './users/interceptors/auth.interceptor';
import { DetailInvoiceComponent } from './invoices/detail-invoice.component';
import { InvoicesComponent } from './invoices/invoices.component';

import { MatAutocompleteModule }from '@angular/material/autocomplete';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';

const routes : Routes = [
  {path: '', redirectTo :'/clients', pathMatch:'full'},
  {path: 'directives', component: DirectiveComponent },
  {path: 'clients', component: ClientsComponent },
  {path: 'clients/page/:page', component:ClientsComponent},
  {path: 'clients/form', component : FormComponent, canActivate : [AuthGuard,RoleGuard], data:{ role : 'ROLE_ADMIN' } },
  {path: 'clients/form/:id', component : FormComponent, canActivate : [AuthGuard,RoleGuard],  data:{ role : 'ROLE_ADMIN' } },
  {path: 'login', component : LoginComponent},
  {path: 'invoices/:id', component : DetailInvoiceComponent },
  {path: 'invoices/form/:clientId', component : InvoicesComponent}
]

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    FooterComponent,
    DirectiveComponent,
    ClientsComponent,
    FormComponent,
    PaginatorComponent,
    DetailComponent,
    LoginComponent,
    DetailInvoiceComponent,
    InvoicesComponent
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    RouterModule.forRoot(routes),
    BrowserAnimationsModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatMomentDateModule,
    ReactiveFormsModule, MatAutocompleteModule,MatInputModule,MatFormFieldModule
  ],
  providers: [ClientService,AuthService,
  { provide : HTTP_INTERCEPTORS, useClass : TokenInterceptor, multi:true},
  { provide : HTTP_INTERCEPTORS, useClass : AuthInterceptor, multi:true} ],
  bootstrap: [AppComponent]
})
export class AppModule { }
