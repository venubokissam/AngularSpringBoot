import { Injectable } from '@angular/core';
import { CLIENTS } from './clients.json';
import { Client } from './client';
import { DatePipe } from '@angular/common';
import { Observable } from 'rxjs';
import { of, throwError } from 'rxjs';
import { HttpClient, HttpRequest, HttpEvent } from '@angular/common/http';
import { tap, map, catchError } from 'rxjs/operators';
import { Router } from '@angular/router';
import { Region } from './region';


@Injectable({
  providedIn: 'root'
})
export class ClientService {

  private urlEndPoint: string = "http://localhost:8080/api/clients";

  constructor(private http: HttpClient,
    private router: Router) { }



  getClients(page: number): Observable<any> {
    //return this.http.get<Client[]>(this.urlEndPoint);
    return this.http.get(this.urlEndPoint + '/page/' + page).pipe(

      tap((response: any) => {
        console.log('CLientService Tap : 1');
        (response.content as Client[]).forEach(client => {
          console.log(client.firstName);
        })
      }),

      map((response: any) => {
        (response.content as Client[]).map(client => {
          let datePipe = new DatePipe('en-US');
          client.firstName = client.firstName.toUpperCase();
          client.createdDate = datePipe.transform(client.createdDate, 'dd/MM/yyyy');
          return client;
        });
        return response;
      })
    )

  }

  create(client: Client): Observable<Client> {
    return this.http.post(this.urlEndPoint, client).pipe(
      map((response: any) => response.client as Client),
      catchError(e => {
        if (e.status == 400) {
          return throwError(e);
        }
        return throwError(e);
      })
    );
  }

  getClient(id): Observable<Client> {
    return this.http.get<Client>(`${this.urlEndPoint}/${id}`).pipe(
      catchError(e => {
        if (e.status != 401 && e.error.message) {
          this.router.navigate(['/clients']);
        }
        return throwError(e);
      }
      )
    )
  }

  update(client: Client): Observable<any> {
    console.log(this.urlEndPoint);

    return this.http.put<any>(`${this.urlEndPoint}/${client.id}`, client).pipe(
      catchError(e => {


        if (e.status == 400) {
          return throwError(e);
        }

        // this.router.navigate(['/clients']);

        return throwError(e);
      }
      )
    )
  }

  delete(id: number): Observable<Client> {
    return this.http.delete<Client>(`${this.urlEndPoint}/${id}`).pipe(
      catchError(e => {
        this.router.navigate(['/clients']);
        return throwError(e);
      }
      )
    )
  }

  submitPhoto(archive: File, id): Observable<HttpEvent<{}>> {
    let formData = new FormData();
    formData.append("archive", archive);
    formData.append("id", id);

    const req = new HttpRequest('POST', `${this.urlEndPoint}/upload/`, formData, {
      reportProgress: true
    });
    return this.http.request(req);

  }

  getRegions(): Observable<Region[]> {
    return this.http.get<Region[]>(this.urlEndPoint + '/regions');
  }

}
