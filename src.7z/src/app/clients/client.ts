import { Region } from './region';
import { Invoice } from '../invoices/models/invoice';

export class Client{
    id : number;
    firstName : string;
    lastName : string;
    createdDate : string;
    email : string;
    photo : string;
    region : Region;
    invoices : Array<Invoice>[];

}