import { Component, OnInit } from '@angular/core';
import { Client } from './client';
import { ClientService } from './client.service';
import Swal from 'sweetalert2';
import { ActivatedRoute } from '@angular/router';
import { ModelService } from './detail/model.service';
import { AuthService } from '../users/auth.service';

@Component({
  selector: 'app-clients',
  templateUrl: './clients.component.html',
  styleUrls: ['./clients.component.scss']
})
export class ClientsComponent implements OnInit {

  clients: Client[];
  paginator : any;
  selectClient : Client;

  constructor(private clientService: ClientService,
    private modelService : ModelService,
    private activatedRoute: ActivatedRoute,
    private authService: AuthService) { }

  ngOnInit() {
    this.activatedRoute.paramMap.subscribe(params => {
      let page: number = +params.get('page');
      if (!page) {
        page = 0;
      }
      this.clientService.getClients(page).subscribe(
        response => {
          this.clients = response.content as Client[];
          this.paginator = response;
        });
    }
    );

    this.modelService.uploadNotification.subscribe(client=>{
      this.clients = this.clients.map(clientOriginal=>{
        if(client.id==clientOriginal.id){
          clientOriginal.photo=client.photo;
        }
        return clientOriginal;
      })
    })
  }

  delete(client: Client): void {

    const swalWithBootstrapButtons = Swal.mixin({
      customClass: {
        confirmButton: 'btn btn-success',
        cancelButton: 'btn btn-danger'
      },
      buttonsStyling: false
    })

    swalWithBootstrapButtons.fire({
      title: 'Please Confirm!',
      text: `Are you sure to delete Client ${client.firstName} ${client.lastName}?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, Confirm',
      cancelButtonText: 'No, cancel!',
      reverseButtons: true
    }).then((result) => {
      if (result.value) {
        this.clientService.delete(client.id).subscribe(
          response => {
            this.clients = this.clients.filter(clie => clie !== client);
            swalWithBootstrapButtons.fire(
              'Deleted!',
              'Your file has been deleted.',
              'success'
            )
          }
        )

      }
    })

  }

  openModel(client : Client){
    this.selectClient = client;
    this.modelService.openModel();
  }
}
