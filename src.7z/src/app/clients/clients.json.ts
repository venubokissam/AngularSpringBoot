import { Client } from './client';

export const CLIENTS : Client []=[
    // { id:1, firstName:"Venu", lastName:"Bokissam" ,createdDate:"2017-12-11", email: "venu@gmail.com"},
    // { id:2, firstName:"Rajubai", lastName:"Rajubai1" ,createdDate:"2017-12-12", email: "venuyrte@gmail.com"},
    // { id:3, firstName:"Mohan Rao", lastName:"Bokissam" ,createdDate:"2017-12-13", email: "venujsdjud@gmail.com"},
    // { id:4, firstName:"Ravi Teja", lastName:"RaviTejaRao" ,createdDate:"2017-12-15", email: "venu@gmail.com"},
    // { id:5, firstName:"Sudheer Babu", lastName:"Bokissam" ,createdDate:"2017-11-11", email: "venu@gmail.com"},
    // { id:6, firstName:"Raju pinni", lastName:"pinnisetty" ,createdDate:"2017-11-11", email: "venu@gmail.com"},
    // { id:7, firstName:"Rani fotu", lastName:"Bokissam" ,createdDate:"2017-17-11", email: "venurajuramesj@gmail.com"},
    // { id:8, firstName:"Akil Mohan", lastName:"pinn1" ,createdDate:"2017-11-11", email: "venuvneuvneuvneu@gmail.com"},
    // { id:9, firstName:"Venkat", lastName:"Bokissam" ,createdDate:"2017-09-11", email: "venu@gmail.com"},
    // { id:10, firstName:"Bala babu", lastName:"pinniventks" ,createdDate:"2017-08-11", email: "venu@gmail.com"},
  ];