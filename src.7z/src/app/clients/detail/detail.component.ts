import { Component, OnInit, Input } from '@angular/core';
import { Client } from '../client';
import { ClientService } from '../client.service';
import { ActivatedRoute } from '@angular/router';
import Swal from 'sweetalert2';
import { HttpEventType } from '@angular/common/http';
import { ModelService } from './model.service';
import { AuthService } from '../../users/auth.service';
import { InvoiceService } from '../../invoices/services/invoice.service';
import { Invoice } from '../../invoices/models/invoice';

@Component({
  selector: 'app-detail',
  templateUrl: './detail.component.html',
  styleUrls: ['./detail.component.scss']
})
export class DetailComponent implements OnInit {

  @Input() client : Client;
  title : string ="Client Details";
  private photoSelect : File;
  progress :number = 0;
  invoice : Invoice[];

  constructor(private  ClientService : ClientService,
    private modelService : ModelService,
    private  activatedRoute : ActivatedRoute,
    private authService : AuthService,
    private invoiceService : InvoiceService) { }

  ngOnInit() {
  
  }
  
  selectPhoto(event){
    this.photoSelect = event.target.files[0];
    this.progress = 0;
    console.log(this.photoSelect);
    if(this.photoSelect.type.indexOf('image')<0){
      Swal.fire('Error Selection Image','Please check the file format you are uploading','error');
      this.photoSelect= null; 
    }
  }
  submitPhoto(){
if(!this.photoSelect){
   Swal.fire('Error Uplaod','Please select the file you want to upload','error');
}else{

    this.ClientService.submitPhoto(this.photoSelect,this.client.id).subscribe(
      event=>{

        if(event.type===HttpEventType.UploadProgress){
                this.progress = Math.round((event.loaded/event.total)*100);
        }else{
          if(event.type===HttpEventType.Response){
             let response :any = event.body;
             this.client = response.client as Client;
             this.modelService.uploadNotification.emit(this.client);

             Swal.fire('Photo has uploaded successfully',response.message,'success');
          }
        }

       
      }
    )
  }
  }

  closeModel(){
    this.modelService.closeModel();
    this.selectPhoto = null;
    this.progress=0;
  }

  delete(invoice : Invoice) : void{

    const swalWithBootstrapButtons = Swal.mixin({
      customClass: {
        confirmButton: 'btn btn-success',
        cancelButton: 'btn btn-danger'
      },
      buttonsStyling: false
    })

    swalWithBootstrapButtons.fire({
      title: 'Please Confirm!',
      text: `Are you sure to delete Invoice ${invoice.description}?`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonText: 'Yes, Confirm',
      cancelButtonText: 'No, cancel!',
      reverseButtons: true
    }).then((result) => {
      if (result.value) {
        this.invoiceService.delete(invoice.id).subscribe(
          () => {
            this.client.invoices = this.client.invoices.filter(i => i !== this.invoice)
            swalWithBootstrapButtons.fire(
              'Deleted!',
              `Invoice ${invoice.description}  has been deleted.`,
              'success'
            )
          }
        )

      }
    })


  }

}
