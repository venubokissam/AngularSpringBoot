import { Injectable , EventEmitter, Output} from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class ModelService {

    model: boolean = false;
    @Output() _uploadNotification = new EventEmitter<any>();
    
    constructor() {

    }

    get uploadNotification() :  EventEmitter<any>{
       return this._uploadNotification;
    }
    
    openModel() {
        this.model = true;
    }
    closeModel() {
        this.model = false;
    }
}