import { Component, OnInit } from '@angular/core';
import { Client } from './client';
import { ClientService } from './client.service';
import { Router,ActivatedRoute} from '@angular/router';
import Swal from 'sweetalert2'
import { Region } from './region';

@Component({
  selector: 'app-form',
  templateUrl: './form.component.html',
  styleUrls: ['./form.component.scss']
})
export class FormComponent implements OnInit {

private client : Client = new Client();
private title : string = "Create Client";
private reportErrors : string[];
regions : Region[];

  constructor(private clientService : ClientService,
    private router : Router,
    private activatedRoute : ActivatedRoute) { }

  ngOnInit() {
    this.loadClient();
    this.loadRegions();
  }

  public loadClient() : void {
       this.activatedRoute.params.subscribe(
         params=>{
           let id = params['id']
           if(id){
                    this.clientService.getClient(id).subscribe(
                      client=> this.client=client
                    )
           }
         }
       )
  }
  public create() : void{
          this.clientService.create(this.client).subscribe(
            client => {
              this.router.navigate(['/clients']);
              console.log(client);
              Swal.fire('New Client', `Client ${client.firstName} Created Succesfully!`,'success');
            },
            err=> {
              this.reportErrors = err.error.errors as string[];
              console.error('Error code from backend' +err.status);
              console.error(err.error.errors);
            }
          );
  }

  public update():void{
              this.clientService.update(this.client).subscribe(
                json =>{
                     this.router.navigate(['/clients']);
                     Swal.fire('Client Updated',`Client ${json.client.firstName} Updated Successfully!`,'success');
                },
                err=> {
                  this.reportErrors = err.error.errors as string[];
                  console.error('Error code from backend' +err.status);
                  console.error(err.error.errors);
                }
              )
  }

  public loadRegions():void{
        this.clientService.getRegions().subscribe(regions=> this.regions=regions);
  }

  compareRegion(o1:Region,o2:Region):boolean{
    if(o1===undefined || o2===undefined){
      return true;
    }
    return o1===null||o2===null||o1===undefined||o2===undefined?false:o1.id===o2.id;
  }
}
