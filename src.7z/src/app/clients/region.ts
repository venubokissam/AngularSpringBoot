export class Region{
    id : string;
    name : string;
}