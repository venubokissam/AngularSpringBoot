import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-directive',
  templateUrl: './directive.component.html',
  styleUrls: ['./directive.component.scss']
})
export class DirectiveComponent implements OnInit {

  directiveList : string []=["Java","TypeScript","CSS","HTML","C#","JavaScript"];
  isDirective : boolean = true;
  constructor() { }


  ngOnInit() {
  }

  setDirective() : void{
    this.isDirective = (this.isDirective==true)? false :true;
  }
}
