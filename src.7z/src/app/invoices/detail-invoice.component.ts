import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Invoice } from './models/invoice';
import { InvoiceService } from './services/invoice.service';

@Component({
  selector: 'app-detail-invoice',
  templateUrl: './detail-invoice.component.html'
})
export class DetailInvoiceComponent implements OnInit {

  
  invoice : Invoice;
  title : string = 'Invoice';

  constructor(private invoiceService : InvoiceService,
    private activatedRoute : ActivatedRoute) { }

  ngOnInit() {
    this.activatedRoute.paramMap.subscribe(params=>{
    let id = +params.get('id');
    this.invoiceService.getInvoice(id).subscribe(invoice=>this.invoice=invoice);
    });
  }

}
