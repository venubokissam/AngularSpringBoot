import { Component, OnInit } from '@angular/core';
import { Invoice } from './models/invoice';
import { ClientService } from '../clients/client.service';
import { ActivatedRoute } from '@angular/router';
import { FormControl } from '@angular/forms';
import { Observable } from 'rxjs';
import { map,flatMap } from 'rxjs/operators';
import { InvoiceService } from '../invoices/services/invoice.service';
import { Product } from './models/product';
import { InvoiceItem } from './models/invoice-item';
import { MatAutocompleteSelectedEvent } from '@angular/material';

@Component({
  selector: 'app-invoices',
  templateUrl: './invoices.component.html',
  styleUrls: ['./invoices.component.scss']
})
export class InvoicesComponent implements OnInit {

  title:string = 'New Invoice';
  invoice : Invoice = new Invoice();

  autocompleteControl = new FormControl();
  products: string[] = ['One','Two','Three'];
  filterProducts : Observable<Product[]>;

  constructor(private clientService : ClientService,
    private activatedRoute : ActivatedRoute,
    private invoiceService : InvoiceService
    ) { }

  ngOnInit() {
    this.activatedRoute.paramMap.subscribe(params=>{
      let clientId = +params.get('clientId');
      this.clientService.getClient(clientId).subscribe(client=> this.invoice.client = client);
    });

    this.filterProducts = this.autocompleteControl.valueChanges.pipe(
      map(value => typeof value === 'string'? value:value.productName),
      flatMap(value => value ? this._filter(value):[])
    );
    
  }

  private _filter(value:string) : Observable<Product[]>{
      const filterValue = value.toLowerCase();
      return this.invoiceService.filterProducts(filterValue);
  }

  displayProduct(product?:Product):string | undefined{
    return product? product.productName: undefined;
  }

selectProduct(event : MatAutocompleteSelectedEvent):void{
let product = event.option.value as Product;
console.log(product);

let newItem = new InvoiceItem();
newItem.product=product;
console.log(newItem);
this.invoice.items.push(newItem);

this.autocompleteControl.setValue('');
event.option.focus();
event.option.deselect();
  }

  updateQuantiy(id:number,event:any){
   
    let quantity:number = event.target.value as number;

    this.invoice.items = this.invoice.items.map((item : InvoiceItem) =>{
      if(id === item.product.id){
        item.quantity = quantity;
      }
      return item;
    })
  }

}
