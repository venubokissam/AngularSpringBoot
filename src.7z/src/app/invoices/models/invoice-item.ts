import { Product } from './product';

export class InvoiceItem {

    quantity : number =1;
    product : Product;
    amount : number;

    public claculateAmount() : number {
        return this.quantity * this.product.productPrice;
    }
}
