import { InvoiceItem } from './invoice-item';
import { Client } from '../../clients/client';

export class Invoice {

    id : number;
    description : string;
    remarks : string;
    items : Array<InvoiceItem>=[];
    client : Client;
    total : number;
    createAt : string;
}

