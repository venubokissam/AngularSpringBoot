export class Product {

    id : number;
    productName : string;
    productPrice : number;
    createAt : string;
}
