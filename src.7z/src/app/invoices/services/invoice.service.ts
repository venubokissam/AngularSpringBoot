import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Invoice } from '../models/invoice';
import { Product } from '../models/product';
@Injectable({
  providedIn: 'root'
})
export class InvoiceService {

  private urlEndPoint: string = 'http://localhost:8080/api/invoices';

  constructor(private http: HttpClient) { }

  getInvoice(id: number): Observable<Invoice> {
    return this.http.get<Invoice>(`${this.urlEndPoint}/${id}`);

  }

  delete(id:number):Observable<void>{
     return this.http.delete<void>(`${this.urlEndPoint}/${id}`);
  }

  filterProducts(term:string):Observable<Product[]>{
    return this.http.get<Product[]>(`${this.urlEndPoint}/filter-products/${term}`);
  }
}
