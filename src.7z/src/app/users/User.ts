export class User{

    id : number;
    username : string;
    password : string;
    name : string;
    lastname:string;
    email : string;
    roles:string[]=[];

}