import { Component, OnInit } from '@angular/core';
import { User } from './User';
import Swal from 'sweetalert2';
import { AuthService } from './auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html'
})
export class LoginComponent implements OnInit {

  title: string = "Please Sign In!"
  user: User;

  constructor(private authService : AuthService, private router : Router) { 
    this.user = new User();
  }

  ngOnInit() {
    if(this.authService.isAuthenticated()){
      Swal.fire('Login',`User ${this.authService.user.username} has already authenticated!`,'info');
      this.router.navigate(['/clients']);
    }
  }

  login(): void {
    console.log(this.user);
    if (this.user.username == null || this.user.password == null) {
      Swal.fire('Error Login', 'Please enter Username and Password', 'error');
    }

    this.authService.login(this.user).subscribe(response =>{
    console.log(response);  

    this.authService.grantUser(response.access_token);
    this.authService.grantToken(response.access_token);
    let user = this.authService.user;
    // let payload = JSON.parse(atob(response.access_token.split(".")[1]));
    // console.log(payload);
    this.router.navigate(['/clients']);
    Swal.fire('Login',`User ${user.username}, has Logged in Successfully`,'success');
    },
    err=>{
      if(err.status==400){
        Swal.fire('Error Login','Username or Password are Incorrect','error');
      }
    }
    );

  }

}
